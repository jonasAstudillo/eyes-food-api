<?php
/**
 * Provee las constantes para conectarse a la base de datos
 * Mysql.
 */
// TODO: cambiar por dominio o IP en producción
define("MYSQL_HOST", "localhost");
define("MYSQL_DATABASE_NAME", "eyesfood");
// TODO: cambiar en producción
define("MYSQL_USERNAME", "root");
// TODO: cambiar en producción
define("MYSQL_PASSWORD", "");
